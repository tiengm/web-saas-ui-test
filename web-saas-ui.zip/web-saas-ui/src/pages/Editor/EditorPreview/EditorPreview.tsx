import React from 'react';
import './EditorPreview.scss';

export const EditorPreview = () => {
    return (
        <div className="ws-editor-preview">
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aut laboriosam, explicabo tempore aperiam
            repellendus atque illo ratione eos odit nisi amet perferendis temporibus. A repellat dolores sequi incidunt
            unde, nesciunt vero ab labore voluptas molestiae, facere excepturi debitis voluptatibus eaque eius porro
            fugiat temporibus et. At adipisci, ipsa consequuntur veniam alias officia earum optio corporis placeat,
            cumque debitis? Expedita magni maiores quam amet nemo fuga quidem molestias cupiditate accusantium accusamus
            distinctio explicabo enim atque ratione fugiat aliquid ut voluptates, illum deleniti voluptatem omnis ex
            hic. Aliquam sint, minima quo architecto minus aperiam veritatis corporis mollitia vel iusto libero
            aspernatur, facere nesciunt dolores similique aliquid ut unde facilis reiciendis, provident totam
            repudiandae quaerat. Cum quidem officiis culpa obcaecati ex quibusdam animi eaque hic itaque sit ipsum
            iusto, facilis non! Voluptas minima reprehenderit omnis, possimus vero voluptatum placeat a expedita
            dolorum? Quae in assumenda officia, architecto doloribus aperiam ut dolore accusantium dignissimos omnis
            quis sit rerum excepturi itaque id quas necessitatibus animi inventore blanditiis quasi porro. Commodi sit
            rerum quisquam asperiores quas, quasi non necessitatibus dolor natus minus laboriosam qui culpa ullam
            aspernatur. Impedit laborum, reprehenderit et provident voluptatibus aut tenetur quidem alias nihil ducimus
            esse veritatis enim obcaecati nesciunt voluptatem autem repellat perferendis molestiae, harum eum omnis
            voluptate dolore. Ex eum ad nisi veniam? Consequuntur architecto optio quibusdam sunt eum ea at dolor ipsum
            accusamus fugit voluptates quia modi reiciendis veniam, eos commodi libero totam amet. Voluptas distinctio
            nemo libero, illum vero in at officiis molestiae tempora accusamus. Iste ex commodi doloribus cum quisquam
            nostrum ipsa dolore? Accusantium laboriosam, dicta ad magni quo fuga qui hic tempore! Esse eum, fuga dolorem
            commodi itaque delectus, vero maiores neque nesciunt possimus hic, exercitationem cupiditate vitae
            molestias. Culpa velit consequatur optio, unde recusandae ipsam iste voluptatem atque, soluta amet
            repellendus praesentium quos dolor adipisci accusantium architecto reprehenderit! Fugit sapiente
            reprehenderit esse necessitatibus totam inventore nostrum non earum molestias culpa porro nobis quia minima
            exercitationem, et soluta quis atque. Aut, unde illo! Ad sunt cupiditate inventore molestiae porro dolorem
            pariatur eligendi fugit id dicta ipsa sequi perspiciatis deleniti voluptatum quia dolore est expedita
            tempora consectetur praesentium, voluptas animi debitis consequatur! Qui dignissimos, obcaecati nostrum,
            aliquid eos impedit recusandae debitis iure, incidunt odit ea nesciunt quam voluptatibus non. Nihil dolores
            eos alias tempore minima dolorum animi temporibus quas. Earum ut, aliquam illum voluptatem deserunt incidunt
            perspiciatis exercitationem, vero debitis temporibus corporis? Totam voluptatum error minima dolor amet,
            reprehenderit quae repellat laborum maxime! Nesciunt minima vero cupiditate sed optio similique molestias,
            officiis quaerat repellendus quo inventore, illum consequuntur consectetur voluptatum, sint provident? Ullam
            similique dolorem ipsam atque vero suscipit veritatis, odio officia ad consequatur! Hic eum aliquam
            doloremque temporibus, deserunt fuga vitae cum rem incidunt obcaecati vel recusandae quod nesciunt ut
            possimus quis laudantium! Hic asperiores et esse aperiam ad enim itaque illo deleniti debitis. Quos
            quibusdam sed repudiandae reprehenderit perspiciatis saepe asperiores nemo, facilis labore exercitationem?
            Sunt alias adipisci corporis commodi optio eos laborum delectus ducimus dicta minus laboriosam
            necessitatibus, rem mollitia assumenda unde veniam magnam aut quod impedit neque perspiciatis fuga ipsa.
            Dolore blanditiis maxime cum suscipit? Dicta nesciunt perspiciatis ea animi. Dolorum laudantium ipsam, odit
            molestiae natus perferendis voluptate sunt quibusdam in laboriosam esse quia fugiat est, ea laborum tempore
            ullam sequi debitis corporis enim alias voluptas? Quos eligendi necessitatibus incidunt atque laborum
            voluptatum eum veniam perspiciatis! Eaque, reprehenderit. Nisi maiores beatae neque aliquam nobis! Quisquam
            alias saepe eaque iure impedit repudiandae ex excepturi labore aliquid quam animi corrupti ipsa eligendi
            laboriosam facere accusantium, quidem soluta autem illo voluptatum minus ipsam! Aut sequi inventore quas
            aliquam corrupti dignissimos nemo aliquid, molestias a quo error, in debitis optio ea necessitatibus. Iusto
            tenetur rem cumque sapiente maxime, exercitationem repellat, suscipit veritatis, perspiciatis odit aliquid
            deleniti reprehenderit eos. Nobis ratione soluta quasi mollitia voluptatum. Expedita rerum laboriosam, amet
            dolores rem architecto accusantium error sequi quibusdam in velit, odio iure quae inventore magnam nihil.
            Consequatur tempora, eveniet sint optio, id expedita nesciunt deleniti quam perferendis labore corporis
            consectetur quibusdam officiis iure delectus eum quod! Quidem tenetur pariatur dicta, debitis eveniet ipsum
            tempore laborum repellat ab quaerat eos explicabo. Veniam aperiam beatae, iste voluptatibus ea dolor dolores
            inventore neque officiis provident nulla recusandae? Accusantium consequatur, error sunt culpa quia
            inventore fuga quis deserunt, corrupti dolorum enim sequi, libero asperiores rem maxime delectus omnis
            consectetur sed sapiente laborum at reiciendis! Consequuntur autem quo ratione dicta perspiciatis omnis quam
            molestiae unde exercitationem. Cum quos consequuntur, nihil laborum atque quas reiciendis voluptatum earum
            nobis ullam veniam nostrum ipsa dolorem harum, aut numquam sunt corrupti in amet, reprehenderit laboriosam
            ea autem! Atque ipsum, expedita aut nam asperiores nostrum, repudiandae tenetur labore iure, voluptatibus
            quod. Quos ex incidunt voluptates, earum minus quidem delectus praesentium, facilis quae explicabo alias
            doloribus omnis reprehenderit similique dolores itaque totam provident cumque nihil, recusandae ullam ab
            temporibus sint. Voluptate, neque possimus nihil corporis recusandae inventore magnam alias sit, itaque ab
            magni mollitia, vel minima suscipit provident? Totam quisquam nihil ex iste distinctio sequi eius debitis
            necessitatibus consectetur, veritatis earum sit non, quis quos? Sunt velit libero veritatis fugit iure
            eveniet quas similique error necessitatibus quasi dolorem dolores, nemo iusto magnam neque? Quia in veniam
            commodi molestias porro nemo aliquid? Ab voluptatum velit facilis, a quia est officia esse magnam
            praesentium sunt nostrum vero laborum, dolorem eaque reiciendis placeat fugit aliquam earum, quaerat amet
            accusamus veniam! Similique, totam at veniam facere, dolore reprehenderit quo autem nobis, ratione ipsam
            illo vitae laudantium neque officiis obcaecati quis a ipsum nam ab alias nulla facilis sequi? Atque sint
            voluptatum ducimus rem fugit necessitatibus. Officiis eligendi a, cupiditate iste voluptatem officia quaerat
            nihil. Voluptas quos velit quo eligendi. Natus cumque nesciunt magnam, harum earum atque? Accusamus in illo
            odit officia similique delectus et aut blanditiis, consectetur sunt, inventore quaerat eos! Voluptatibus
            quod dicta voluptates sint officia voluptas eligendi alias officiis saepe omnis delectus rerum, ea,
            obcaecati exercitationem ratione aperiam iure, cupiditate tempora veniam dolorum quidem. Facilis corrupti
            eos omnis cum asperiores. Pariatur corporis repellendus aspernatur alias ipsum? Reprehenderit, vero?
            Delectus unde ut quas nisi.
        </div>
    );
};
