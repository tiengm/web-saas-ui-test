import React from 'react';
import './EditorNav.scss';

// svgs
import { ReactComponent as PagesIcon } from '~/assets/svgs/pages.svg';
import { ReactComponent as DesignIcon } from '~/assets/svgs/design.svg';
import { ReactComponent as ContentIcon } from '~/assets/svgs/content.svg';
import { ReactComponent as ManageStoreIcon } from '~/assets/svgs/manage-store.svg';
import { ReactComponent as ECommerceIcon } from '~/assets/svgs/e-commerce.svg';
import { ReactComponent as MarketingIcon } from '~/assets/svgs/marketing.svg';
import { ReactComponent as AppStoreIcon } from '~/assets/svgs/app-store.svg';
import { ReactComponent as SettingIcon } from '~/assets/svgs/setting.svg';

// types
import { LeftPanelDialogProps } from '~/types';

import { EditorNavItem } from './EditorNavItem';

export const editorNavList = [
    {
        id: 'id-pages',
        name: 'Pages',
        borderColor: 'var(--color-primary)',
        icon: <PagesIcon />,
        content: <div>Pages</div>,
    },
    {
        id: 'id-design',
        name: 'Design',
        borderColor: 'var(--color-yellow)',
        icon: <DesignIcon />,
        content: <div>Design</div>,
    },
    {
        id: 'id-content',
        name: 'Content',
        borderColor: 'var(--color-pink)',
        icon: <ContentIcon />,
        content: <div>Content</div>,
    },
    {
        id: 'id-manage-store',
        name: 'Manage Store',
        borderColor: 'var(--color-purple)',
        icon: <ManageStoreIcon />,
        content: <div>Manage Store</div>,
    },
    {
        id: 'id-e-commerce',
        name: 'E-Commerce',
        borderColor: 'var(--color-orange)',
        icon: <ECommerceIcon />,
        content: <div>E-Commerce</div>,
    },
    {
        id: 'id-marketing',
        name: 'Marketing',
        borderColor: 'var(--color-green)',
        icon: <MarketingIcon />,
        content: <div>Marketing</div>,
    },
    {
        id: 'id-app-store',
        name: 'App Store',
        borderColor: 'var(--color-primary)',
        icon: <AppStoreIcon />,
        content: <div>App Store</div>,
    },
    {
        id: 'id-setting',
        name: 'Setting',
        borderColor: 'var(--color-primary)',
        icon: <SettingIcon />,
        content: <div>Setting</div>,
    },
];

interface EditorNavItemProps {
    isVisible: boolean;
    onVisible: () => void;
    setDialog: (dialog: LeftPanelDialogProps) => void;
    setBorderColor: (color: string) => void;
}

export const EditorNav = ({ isVisible, onVisible, setDialog, setBorderColor }: EditorNavItemProps) => {
    return (
        <nav className="ws-editor-nav">
            {editorNavList.map((item) => (
                <EditorNavItem
                    key={item.id}
                    {...item}
                    isVisible={isVisible}
                    onVisible={onVisible}
                    setDialog={setDialog}
                    setBorderColor={setBorderColor}
                />
            ))}
        </nav>
    );
};
