import React, { useState } from 'react';
import classnames from 'classnames';
import Tippy from '@tippyjs/react';
import './EditorNavItem.scss';

// types
import { LeftPanelDialogProps } from '~/types';

interface EditorNavItemProps extends LeftPanelDialogProps {
    icon: React.ReactNode;
    isVisible: boolean;
    onVisible: () => void;
    setDialog: (dialog: LeftPanelDialogProps) => void;
    setBorderColor: (color: string) => void;
}

export const EditorNavItem = ({
    id,
    name,
    borderColor,
    content,
    icon,
    isVisible,
    onVisible,
    setDialog,
    setBorderColor,
}: EditorNavItemProps) => {
    const handleClick = () => {
        setDialog({ id, name, borderColor, content });
        onVisible();
        setBorderColor(borderColor);
    };

    return (
        <Tippy
            className="ws-editor-nav-tippy"
            content={<div className="ws-text-truncation font-14r">{name}</div>}
            arrow={false}
            interactive={true}
            duration={200}
            placement="right"
        >
            <div
                className={classnames('ws-editor-nav__item', {
                    // 'ws-editor-nav__item--active': isVisible,
                })}
                onClick={handleClick}
            >
                <div className="ws-editor-nav__icon">{icon}</div>
            </div>
        </Tippy>
    );
};
