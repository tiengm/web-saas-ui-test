import React from 'react';
import Tippy from '@tippyjs/react';
import './EditorNotifications.scss';

// svgs
import { ReactComponent as NotificationsIcon } from '~/assets/svgs/notifications.svg';
import { ReactComponent as NotificationsOutlineIcon } from '~/assets/svgs/notifications-outline.svg';

import { Notifications } from './Notifications';

export const EditorNotifications = () => {
    return (
        <div className="ws-editor-notifications">
            <Tippy
                className="ws-editor-notifications-tippy"
                arrow={false}
                content={<Notifications />}
                interactive={true}
                duration={200}
                trigger="click"
                placement="right"
            >
                <div className="ws-editor-notifications__icon">
                    <NotificationsIcon />
                    <div className="ws-editor-notifications__icon__number">9+</div>
                </div>
            </Tippy>
        </div>
    );
};
