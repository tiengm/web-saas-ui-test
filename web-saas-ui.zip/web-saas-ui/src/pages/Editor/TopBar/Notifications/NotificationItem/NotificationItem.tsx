import React from 'react';
import classnames from 'classnames';
import './NotificationItem.scss';

// svgs
import { ReactComponent as EllipseIcon } from '~/assets/svgs/ellipse.svg';

interface NotificationItemProps {
    isRead?: boolean;
}

export const NotificationItem = ({ isRead }: NotificationItemProps) => {
    return (
        <div className="ws-notification__item">
            <div className={classnames('ws-notification__container', { 'ws-notification--unread': !isRead })}>
                <div className="ws-notification__content">
                    <div className="ws-notification__text">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt esse rerum quod! Modi nulla
                        suscipit quam sint eaque, cumque laudantium?Lorem ipsum, dolor sit amet consectetur adipisicing
                        elit. Quos, eaque?
                    </div>
                    <div className="ws-notification__time">1h ago</div>
                </div>
                {!isRead && (
                    <div className="ws-notification__suffix-icon">
                        <EllipseIcon />
                    </div>
                )}
            </div>
        </div>
    );
};
