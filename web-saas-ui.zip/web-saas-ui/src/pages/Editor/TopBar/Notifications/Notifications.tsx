import React from 'react';
import './Notifications.scss';

import { NotificationItem } from './NotificationItem';

export const Notifications = () => {
    return (
        <div className="ws-notifications">
            <div className="ws-notifications__head">
                <div className="ws-notifications__title font-24m">Notifications</div>
                <div className="ws-notifications__button">Clear all</div>
            </div>
            <div className="ws-notifications__body">
                <NotificationItem isRead />
                <NotificationItem isRead />
                <NotificationItem />
                <NotificationItem />
                <NotificationItem />
                <NotificationItem />
                <NotificationItem />
                <NotificationItem />
                <NotificationItem />
                <NotificationItem />
                <NotificationItem />
                <NotificationItem />
                <NotificationItem />
            </div>
        </div>
    );
};
