export interface LeftPanelDialogProps {
    id: string;
    name: string;
    borderColor: string;
    content: React.ReactNode;
}
