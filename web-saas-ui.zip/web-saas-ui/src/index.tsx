import React from 'react';
import ReactDOM from 'react-dom/client';
import { ErrorBoundary } from 'react-error-boundary';
import { HelmetProvider } from 'react-helmet-async';
import reportWebVitals from './reportWebVitals';

import App from './App';

// components
import { AppLoading } from '~/components/AppLoading';
import { ErrorFallback } from '~/components/ErrorFallback';
import { GlobalStyles } from '~/components/GlobalStyles';

// contexts
import { GlobalProvider } from '~/contexts/GlobalContext';

// locales
import '~/locales/i18n';

const root = ReactDOM.createRoot(document.getElementById('root') as HTMLElement);
root.render(
    <React.StrictMode>
        <React.Suspense fallback={<AppLoading />}>
            <ErrorBoundary FallbackComponent={ErrorFallback}>
                <HelmetProvider>
                    <GlobalProvider>
                        <GlobalStyles>
                            <App />
                        </GlobalStyles>
                    </GlobalProvider>
                </HelmetProvider>
            </ErrorBoundary>
        </React.Suspense>
    </React.StrictMode>,
);

reportWebVitals();
