export const LANGUAGES = {
    ENGLISH: 'en',
    VIETNAMESE: 'vi',
};
