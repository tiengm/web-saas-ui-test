export interface GlobalContextState {
    language: string;
    setLanguage: (language: string) => void;
}

export enum GlobalContextActionTypes {
    SET_LANGUAGE = 'SET_LANGUAGE',
}

export type GlobalContextActions = {
    type: string;
    payload: any;
};
