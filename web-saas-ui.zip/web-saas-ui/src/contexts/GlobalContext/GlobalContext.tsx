import React, { createContext, useContext, useReducer } from 'react';
import { GlobalContextActionTypes, GlobalContextState } from './type';
import { globalContextReducer } from './reducer';

// configs
import { LANGUAGES } from '~/configs';

const initialState = {
    language: process.env.REACT_APP_LANGUAGE || localStorage.getItem('i18nextLng') || LANGUAGES.ENGLISH,
    setLanguage: () => {},
};

const GlobalContext = createContext<GlobalContextState>(initialState);

const GlobalProvider: React.FC<Props> = ({ children }) => {
    const [state, dispatch] = useReducer(globalContextReducer, initialState);

    const handleSetLanguage = (language: string) => {
        dispatch({
            type: GlobalContextActionTypes.SET_LANGUAGE,
            payload: { language },
        });
    };

    return (
        <GlobalContext.Provider
            value={{
                ...state,
                setLanguage: handleSetLanguage,
            }}
        >
            {children}
        </GlobalContext.Provider>
    );
};

const useGlobalContext = () => useContext(GlobalContext);

type Props = {
    children: React.ReactNode;
};

export { GlobalContext, GlobalProvider, useGlobalContext };
