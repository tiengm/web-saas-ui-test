import { GlobalContextState, GlobalContextActionTypes, GlobalContextActions } from './type';

export const globalContextReducer = (state: GlobalContextState, action: GlobalContextActions): GlobalContextState => {
    switch (action.type) {
        case GlobalContextActionTypes.SET_LANGUAGE: {
            return {
                ...state,
                language: action.payload.language,
            };
        }
        default:
            return state;
    }
};
